// pages/talk/talk.js
 Page({
   data: {
     mv: []
   },
   /**
    * 生命周期函数--监听页面加载
    */
   onLoad: function (options) {
     let that = this;
     wx.request({
       url: 'https://v1.itooi.cn/netease/mv/top?pageSize=10&page=0',
       //发送请求到服务器
       header: {
         'content-type': 'application/json' // 默认值
       },
       success(res) {
         console.log(res.data)
         that.setData({
           mv: res.data.data
         })
       }
     })
   },
   openPlay: function (e) {
     console.log(e);
     var id = e.currentTarget.dataset.id;
     console.log("id=" + id);
     wx.setStorage({//将数据放入Storage
       key: 'mvInfo',
       data: this.data.mv[id],
     })
     wx.navigateTo({
       url: '../video/video'
     })
   },
   /**
    * 生命周期函数--监听页面初次渲染完成
    */
   onReady: function () {

   },

   /**
    * 生命周期函数--监听页面显示
    */
   onShow: function () {

   },

   /**
    * 生命周期函数--监听页面隐藏
    */
   onHide: function () {

   },

   /**
    * 生命周期函数--监听页面卸载
    */
   onUnload: function () {

   },

   /**
    * 页面相关事件处理函数--监听用户下拉动作
    */
   onPullDownRefresh: function () {

   },

   /**
    * 页面上拉触底事件的处理函数
    */
   onReachBottom: function () {

   },

   /**
    * 用户点击右上角分享
    */
   onShareAppMessage: function () {

   }
 })