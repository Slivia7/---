
// var app = getApp();
// var util = require('../util/util.js');

Page({
    data: {
        hotCommentList: [],
        newCommentList: [],
        myCommentLsit: ['555'],
        vid: 0,
        myNickname: '',
        myImg: '',
        myUrl:'',
        flag:false
    },

change:function(e){
    if(!flag){
        that.setData({
            flag:true,
            myUrl:'../../images/good2.png'
        });
    }
    // else{
    //    that. setData({
    //     flag=false,
    //         myUrl: '../../images/good2.png'
    //     });
    // }
},
    saveComment:function(e){
        var obj=e.detail.value;
        var detail=obj.detail;
        console.log(detail);
        if(detail.length<=0){
            return
        }else{
            this.data.newCommentList.push(obj);
            var update=this.data.notes;
            console.log(updata);
            app.globaData.newCommentList=update;
            // wx.redirectTo({
            //     url: '',
            // })
        }
    },

    getInput: function (e) {
        this.setData({
            newComment: e.detail.value
        })
    },


    formSubmit: function (e) {
        wx.showToast({
            title: '已留言',
            icon: 'success'
        })
        // var that = this;
        // var liuyantext = e.detail.value.liuyantext; //获取表单所有name=liuyantext的值     
        // var nickName = myNickname; //获取表单所有name=nickName的值     
        // var headimg = myImg; //获取表单所有name=headimg的值     
        // wx.request({
        //     url: 'http://localhost/liuyanserver/liuyan.php?liuyantext=' + liuyantext + '&nickname=' + nickName + '&headimg=' + headimg,
        //     data: {
        //         liuyantext,
        //         nickName,
        //         headimg
        //     },
        //     header: {
        //         'Content-Type': 'application/json'
        //     },
        //     success: function(res) {
        //         console.log(res.data) 
        //         that.setData({
        //             re: res.data,
        //         }) 
        //         wx.hideToast();
        //     }
        // })
    },
    // onPullDownRefresh: function() {
    //     wx.showNavigationBarLoading();
    //     var that = this
    //      wx.request({
    //         url: 'http://localhost/liuyanserver/loadliuyan.php',
    //         headers: {
    //             'Content-Type': 'application/json'
    //         },
    //         success: function(res) { //将获取到的json数据，存在名字叫list的这个数组中        
    //             that.setData({
    //                 liuyanlist: res.data, //res代表success函数的事件对，data是固定的，liuyanlist是数组        
    //             })
    //             // 隐藏导航栏加载框       
    //             wx.hideNavigationBarLoading(); // 停止下拉动作        
    //             wx.stopPullDownRefresh();
    //         }
    //     })
    // }, //加载最新数据 

    // formSubmit: function(e) {
    //     console.log(app.globalData.userInfo.nickName);
    //     wx.showToast({
    //         title: '评论成功',
    //         icon: 'success',
    //         duration: 3000
    //     })
    //     var liuyantext = e.detail.value.liuyantext; //获取表单所有name=liuyantext的值 
    //     // console.log('视频id' + that.data.id);
    //     // console.log('留言number:' + that.data.number);
    //     // wx.request({
    //     //     url: 'https://xxxx/comment',
    //     //     data: {
    //     //         content: liuyantext,
    //     //         name: myNickname,
    // //     //         img:myImg
    // //     //     },
    //         header: {
    //             'Content-Type': 'application/json'
    //         },
    //         success: function (res) {
    //             // console.log(res.data)
    //             that.setData({
    //                 showOrHidden: true,
    //                 re: res.data,
    //                 keyValue: '',
    //                 photo2: res.data.result.comment.photo,
    //                 nickname2: res.data.result.comment.nickname,
    //                 date2: res.data.result.comment.date,
    //                 comment2: res.data.result.comment.comment
    //             })
    //             wx.hideToast();
    //             console.log(res);
    //         }
    //     })
    // },

    //     onLoad: function() {
    //         let that = this;




    //         wx.request({
    //             url: 'http://localhost/liuyanserver/loadliuyan.php',
    //             headers: {
    //                 'Content-Type': 'application/json'
    //             },
    //             success: function(res) { //将获取到的json数据，存在名字叫list的这个数组中        
    //                 that.setData({
    //                     liuyanlist: res.data, //res代表success函数的事件对，data是固定的，liuyanlist是数组        
    //                 })
    //             }
    //         })
    //     },

    onLoad: function (options) {
        let that = this;
        wx.getStorage({
            key: 'videoID',
            success: function (res) {
                that.setData({
                    vid: res.data,

                })

                var vid = that.data.vid;
                console.log(vid);
                wx.request({

                    url: 'https://v1.itooi.cn/netease/comment/mv/hot?',
                    method: "GET",
                    data: {
                        id: vid,
                        page: '0',
                        pageSize: '1080',
                    },
                    header: {
                        'content-type': 'application/json' // 默认值
                    },
                    success(res) {
                        console.log(res.data)
                        that.setData({
                            hotCommentList: res.data.data.hotComments,
                        })
                    }
                })

                wx.request({
                    url: 'https://v1.itooi.cn/netease/comment/mv?',
                    method: "GET",
                    data: {
                        id: vid,
                        page: '0',
                        pageSize: '1080',

                    },
                    header: {
                        'content-type': 'application/json' // 默认值
                    },
                    success(res) {

                        that.setData({
                            newCommentList: res.data.data.comments,
                        })
                    }
                })
                // 获取用户信息        
                wx.getSetting({
                    success(res) {
                        if (res.authSetting['scope.userInfo']) {
                            // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                            wx.getUserInfo({
                                success: function (res) {
                                    console.log(res.userInfo);
                                    // console.log(res.userInfo.avatarUrl);
                                    that.setData({
                                        // user:res.userInfo,
                                        myNickname: res.userInfo.nickName,
                                        myImg: res.userInfo.avatarUrl
                                    })

                                }
                            })
                        }
                    }
                })
            }
        })
        /*
        wx.request({
            url: 'http://localhost/liuyanserver/loadliuyan.php',
            headers: {
                'Content-Type': 'application/json'
            },
            success: function(res) { //将获取到的json数据，存在名字叫list的这个数组中        
                that.setData({
                    liuyanlist: res.data, //res代表success函数的事件对，data是固定的，liuyanlist是数组        
                })
            }
        })*/

    },

    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})