// pages/music/history.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    historyList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;





  },



  playall: function (a) {
    var id = a.currentTarget.dataset.id;

    wx.setStorage({
      key: 'songInfo',
      data: this.data.historyList[0],
    })
    wx.navigateTo({
      url: '../play/play',
    })
  },

  tip: function () {
    wx.navigateTo({
      url: '../music/select',
    })
  },




  openPlay: function (e) {
    var id = e.currentTarget.dataset.id;

    wx.setStorage({
      key: 'songInfo',
      data: this.data.historyList[id],
    })
    wx.navigateTo({
      url: '../play/play',
    })
  },

  tip: function () {
    wx.navigateTo({
      url: '../music/select',
    })
  },
  dele: function () {
    let that = this;
    wx.getStorageInfo({
      success(res) {
        console.log(res.keys)
        console.log(res.currentSize)
        console.log(res.limitSize)

        for (var i = res.keys.length - 1; i > 0; i--) {
          
          wx.removeStorageSync(res.keys[i]);
          
        }

      }
    })
    that.setData({
      historyList: null
    })
  },

  // 弹出窗口的方法!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!11
  showModal: function (a) {

    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)


  },
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    wx.getStorageInfo({
      success(res) {
        console.log(res.keys)
        console.log(res.currentSize)
        console.log(res.limitSize)
        var arr = new Array();
        for (var i = res.keys.length - 1; i > 0; i--) {
          if (res.keys[i]=="songInfo"){}
          else{arr.push(wx.getStorageSync(res.keys[i]))
          }
        }


        that.setData({
          historyList: arr
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})