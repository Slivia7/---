// pages/play/play.js
let _animation; // 动画实体
let _animationAngle = 0; // 当前旋转角度
let _animationIntervalId = -1; // 动画定时任务id，通过setInterval来达到无限旋转，记录id，用于结束定时任务
const _ANIMATION_TIME = 800 / 30; 
const myMusic = wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    murl: '',
    mname: '',
    mauthor: '',
    mposter: '',
    play: false,
    // myMusic: null,
    playImg: '../../images/play.png',//*******************
    loveImg: '../../images/heart.png',//*******************
    love: null,//*******************
    mPercent: 0,
    animationData: {},
    mtime:0,
    starttime: '00:00', //正在播放时长
    duration: ''  //总时长
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    if (options.mu != null) {
      this.setData({
        murl: options.mu,
        mname: options.mn,
        mauthor: options.ma,
        mposter: options.mp
      });

      myMusic.src = this.data.murl;
      myMusic.autoplay = true;
    }
    else {//列表传参：通过Storage
      let that = this;
      wx.getStorage({
        key: 'songInfo',
        success: function (res) {
          console.log("play-storage" + res.data.name);
          that.setData({
            murl: res.data.url,
            mname: res.data.name,
            mauthor: res.data.singer,
            mposter: res.data.pic,
            mtime: res.data.time
          });
	

var keys = res.data.id;
          var data = res.data;
          wx.setStorageSync(keys, data);

          var key = res.data.id; 
          getApp().globalData.keys.push(key);
          var tdata = res.data;
          wx.setStorageSync(key,tdata);



          console.log("play-storage" + res.data.name);
         
          myMusic.src = res.data.url;
          myMusic.autoplay = true;
          //定时器
          myMusic.onTimeUpdate(() => {
            var offset = myMusic.currentTime;//已经过了几秒
            var currentTime = parseInt(myMusic.currentTime);
            var max = parseInt(myMusic.duration);
            var min = "0" + parseInt(duration / 60);
            var sec = duration % 60;
            if (sec < 10) {
              sec = "0" + sec;
            };
            var starttime = min1 + ':' + sec1;

            var duration = parseInt(myMusic.duration);
            var min1 = "0" + parseInt(duration / 60);
            var sec1 = duration % 60;
            if (sec1 < 10) {
              sec1 = "0" + sec;
            };
            var duration = min1 + ':' + sec1;

            that.setData({
              offset: currentTime,
              starttime: starttime,
              max: max,
              changePlay: true,
              duration: duration
            })

          })
          myMusic.onEnded(() => {
            that.setData({
              starttime: '00:00',
              isOpen: false,
              offset: 0
            })
          })
          that.setData({
            isOpen: true,
            // play:true
          })
          //判断是否喜欢//**************************(写在susse里面不然load的在其他地方收不到this.data，注意在down里面是that，data中的出定义还要在suceess中定义赋值如：myMusic)
          var love = null;
          var a = getApp().globalData.cdata;
          if (a.length == 0) {
            love = false;
          };
          console.log(a.length);
          for (var i = 0; i < a.length; i++) {
            if (a[i].name == res.data.name) {
              love = true;

            }
            else {
              love = false;
            }

          }
          console.log(love);
          if (love) {
            that.setData({
              loveImg: "../../images/heart2.png",

            })

          }
          that.setData({
            love: love
          })
          //**************************

        },
      })


    }


    /*var myMusic= wx.getBackgroundAudioManager();
    myMusic.title=this.data.mname;
    myMusic.src=this.data.murl;*/

    //var myMusic =wx.createInnerAudioContext();
    //myMusic.src=this.data.murl
  },

  sliderChange(e) {
    var that = this
    var offset = parseInt(e.detail.value);
    // myMusic.play();
    myMusic.seek(offset);
    that.setData({
      isOpen: true,
    })
  },

  clock: function () {
    var count = this.data.mPercent;
    this.setData({
      mPercent: ++count
    })
  },



  // 收藏*********************************
  collectionAction() {


    var a = getApp().globalData.cdata;
    console.log(this.data.love);
    if (!this.data.love) {
      this.data.love = true;
      //传输信息到内存 
      console.log(this.data.love);
      this.setData({
        loveImg: "../../images/heart2.png",
        info: { "url": this.data.murl, "singer": this.data.mauthor, "name": this.data.mname, "pic": this.data.mposter,"time":this.data.mtime}
      })
      getApp().globalData.cdata.push(this.data.info);
      console.log(a);
      // wx.setStorageSync('collection',
      // this.data.info)
    }
    else {
      this.setData({
        love: false,
        loveImg: "../../images/heart.png"

      })

      for (var i in a) {
        if (a[i].singer == this.data.mauthor) {
          a.splice(i, 1);
          console.log(a);
        }
      };

    }

    // ********************************


  },

  dele() {
    getApp().globalData.cdata.length = 0
  },


  playOrPause() {
    if (this.data.play) {
      //暂停播放
      this.data.play = false;
      myMusic.pause();
      this.clearAnimationInterval();
      this.setData({
        playImg: "../../images/stop.png",
        isOpen: false
      })
    } else {
      //播放音乐
      this.data.play = true;
      myMusic.play();
      this.startAnimationInterval();
      this.setData({
        playImg: "../../images/play.png",
        isOpen: true
      })
    }
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    _animation = wx.createAnimation({
      duration: 33,
    })
    let that = this;
    _animationIntervalId = setInterval(function () {
      that.rotateAni(++_animationAngle);
    }, _ANIMATION_TIME);
  },

  rotateAni: function (n) {
    _animation.rotate(n).step()
    this.setData({
      animationData: _animation.export()
    })
  },
  startAnimationInterval: function () {
    let that = this;
    _animationIntervalId = setInterval(function () {
      that.rotateAni(++_animationAngle);
    }, _ANIMATION_TIME);
  },
  clearAnimationInterval: function () {
    if (_animationIntervalId > 0) {   // 判断定时器是否在执行
      clearInterval(_animationIntervalId);  // 清除定时器
      _animationIntervalId = 0;
    }
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.data.myMusic.destroy();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})