// pages/collect/collect.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    songList:[],
    num:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  
  },



  openPlay: function (e) {
    //console.log(e);
    //哪个被点击：data-id所传递过来的view的索引，对应到songList的索引
    var id = e.currentTarget.dataset.id;
    console.log("id" + id);
    //传递数据到play界面:基于缓存，将歌曲的所有信息放入缓存，play界面就可以从缓存中取得所有信息
    wx.setStorage({
      key: 'songInfo',
      data: this.data.songList[id],
    })
    wx.navigateTo({
      url: '../play/play'
    })
  },
  
    
  dele: function () {
    getApp().globalData.cdata.length=0;
    console.log('1');
    this.setData({
      songList: null
    })
  },

  back:function()

   {
     wx.navigateTo({
     url: '../../pages/mine/mine',
     
     }) },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      songList: getApp().globalData.cdata,
      num: getApp().globalData.cdata.length
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})