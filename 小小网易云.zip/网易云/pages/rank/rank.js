// pages/rank/rank.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    "data": 
      [{ "name": "新声榜", "picture": "../../images/rank1.jpg" },{ "name": "流行榜", "picture": "../../images/rank2.jpg" },{ "name": "赞赏榜", "picture": "../../images/rank3.jpg" },{ "name": "华语音乐榜", "picture": "../../images/rank4.jpg" },{ "name": "欧美热歌榜", "picture": "../../images/rank5.jpg" },{ "name": "韩语音乐榜", "picture": "../../images/rank6.jpg" },{ "name": "说唱音乐榜", "picture": "../../images/rank7.jpg" },{ "name": "KTV麦榜", "picture": "../../images/rank8.jpg" },{ "name": "电子音乐榜", "picture": "../../images/rank9.jpg" }],
    "site":
      ["https://v1.itooi.cn/tencent/topList?id=27&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=4&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=34&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=5&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=3&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=16&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=58&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=36&pageSize=100&page=0&format=1", "https://v1.itooi.cn/tencent/topList?id=57&pageSize=100&page=0&format=1"],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      
  },

  onPlay:function(e){
    var id = e.currentTarget.dataset.id;
    console.log("id" + id);

    wx.setStorage({
      key: 'rankList',
      data: this.data.data[id-1],
    })

    wx.setStorage({
      key: 'num',
      data: this.data.site[id-1],
    })

    wx.navigateTo({
      url: '../rankingList/rankingList',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})