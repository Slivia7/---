// index/video/video.js
function getRandomColor() {
  const rgb = []
  for (let i = 0; i < 3; ++i) {
    let color = Math.floor(Math.random() * 256).toString(16)
    color = color.length == 1 ? '0' + color : color
    rgb.push(color)
  }
  return '#' + rgb.join('')
}
Page({

  /**
   * 页面的初始数据
   */
  inputValue: '',
  data: {
    vid:0,
    aid:'',
    play:false,
    playImg: '../../images/play1.png',
    
    danmuList:
      [{
        text: '第 1s 出现的弹幕',
        color: '#ff0000',
        time: 1
      },
      {
        text: '第 3s 出现的弹幕',
        color: '#ff00ff',
        time: 3
      }]
  },

  
  bindInputBlur: function (e) {
    this.inputValue = e.detail.value
  },
  //发送弹幕
  bindSendDanmu: function () {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    })
  },
  PlayorPause: function () {
    if (this.data.play) {
      this.data.play=false;
      this.videoContext.play()
      this.setData({
        playImg: "../../images/play1.png"
      })
    }else{
     this.data.play=true;
      this.videoContext.pause()
      this.setData({
        playImg: "../../images/play.png"
      })
    }
  },
  //播放视频
  bindPlay: function () {
    
  },
  //暂停视频
  bindPause: function () {
    
  },
  videoErrorCallback: function (e) {
    console.log('视频错误信息:')
    console.log(e.detail.errMsg)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;
    wx.getStorage({
      key: 'mvInfo',
      success: function (res) {
        that.setData({
         vid:res.data.id,
         aid:res.data.cover,
        })
      }
      }) 
  },
//传出Id到评论
  comment: function (e) {
    wx.setStorage({
      key: 'videoID',
      data: this.data.vid,
    });
    wx.navigateTo({
      url: '../commentPage/commentPage'
    })
    
  },

  play:function(e) {
    //执行全屏方法  
    var videoContext = wx.createVideoContext('myVideo', this);
    videoContext.requestFullScreen();
    this.setData({
      fullScreen: true
    })
  },
  /**关闭视屏 */
  closeVideo:function() {
    //执行退出全屏方法
    var videoContext = wx.createVideoContext('myVideo', this);
    videoContext.exitFullScreen();
  },
  /**视屏进入、退出全屏 */
  fullScreen:function(e) {
    var isFull = e.detail.fullScreen;
    //视屏全屏时显示加载video，非全屏时，不显示加载video
    this.setData({
      fullScreen: isFull
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (res) {
    this.videoContext = wx.createVideoContext('myVideo')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})