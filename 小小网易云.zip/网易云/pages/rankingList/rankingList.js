// pages/rankingList/rankingList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    listName:'',
    listPicture:'',
    num:null,
    songList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    var site='';
    wx.getStorage({
      key: 'rankList',
      success: function(res) {
        console.log("play-storage"+res.data.name);
        that.setData({
          listName: res.data.name,
          listPicture: res.data.picture
        })
      },
    })
    wx.getStorage({
      key: 'num',
      success: function (res) {
        wx.request({
          url: res.data,
          header: {
            'content-type': 'application/json' // 默认值
          },
          success(res) {
            console.log(res.data)//服务器相应数据回来
            // 将服务器相应的数据绑定到data中，界面就可以相应数据
            that.setData({
              songList: res.data.data
            })
          }
        })
        
      },
    })
    
  },

  openPlay: function (e) {
    // 哪个被点击：data-id所传递过来的view索引，对应到songInfo的索引
    var id = e.currentTarget.dataset.id;
    // 传递数据到play界面：基于缓存，将歌曲的所有信息放入缓存，play几句可以从缓存中获取所有信息
    wx.setStorage({
      key: 'songInfo',
      data: this.data.songList[id],
    })

    wx.navigateTo({
      url: '../play/play',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})